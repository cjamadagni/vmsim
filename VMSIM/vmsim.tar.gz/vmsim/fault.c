/*
 * fault.c - Defines the available fault handlers. One example,
 *           fault_random, is provided; be sure to add your handlers 
 	     to fault_handlers[].
 *
 */

#include <vmsim.h>
#include <fault.h>
#include <options.h>
#include <physmem.h>
#include <stdlib.h>
#include <stdio.h>

void fault_random(pte_t *pte, ref_kind_t type);
void fault_clock(pte_t *pte, ref_kind_t type);
void fault_fifo(pte_t *pte, ref_kind_t type);
void fault_lru(pte_t *pte, ref_kind_t type);

fault_handler_info_t fault_handlers[6] = {
  { "random", fault_random },
  { "fifo", fault_fifo },
  { "clock", fault_clock },
  { "lru", fault_lru },
  { NULL, NULL } /* last entry must always be NULL/NULL */
};

void fault_random(pte_t *pte, ref_kind_t type) {
	int frame;
	frame = random() % opts.phys_pages;
	physmem_evict(frame, type);  // if frame is empty, nothing happens
	physmem_load(frame, pte, type);
}

// FIFO replacement 
void fault_fifo(pte_t *pte, ref_kind_t type) {
	printf("FIFO not implemented yet!\n");
}

// CLOCK replacement, sec 9.4.5.2 in OSC 
void fault_clock(pte_t *pte, ref_kind_t type) {
	printf("CLOCK not implemented yet!\n");
}

// LRU replacement 
void fault_lru(pte_t *pte, ref_kind_t type) {
	printf("LRU not implemented yet!\n");
}

